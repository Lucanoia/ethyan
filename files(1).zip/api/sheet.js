const { redis } = require('./_db');
const crypto = require('crypto');

const ID_RE = /^[a-z0-9]{8}$/;

module.exports = async (req, res) => {
  try {
    const id = req.query.id;

    if (req.method === 'GET') {
      if (!ID_RE.test(id || '')) return res.status(400).json({ error: 'Código inválido' });
      const raw = await redis('GET', `sheet:${id}`);
      if (!raw) return res.status(404).json({ error: 'Ficha não encontrada' });
      return res.json(JSON.parse(raw));
    }

    if (req.method === 'POST' || req.method === 'PUT') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
      const sheet = { ...body, updated: Date.now() };
      const raw = JSON.stringify(sheet);
      if (raw.length > 60000) return res.status(413).json({ error: 'Ficha grande demais' });

      if (req.method === 'POST') {
        const newId = crypto.randomBytes(5).toString('hex').slice(0, 8);
        await redis('SET', `sheet:${newId}`, raw);
        await redis('SADD', 'sheets', newId);
        return res.json({ id: newId });
      }
      if (!ID_RE.test(id || '')) return res.status(400).json({ error: 'Código inválido' });
      if (!(await redis('EXISTS', `sheet:${id}`))) return res.status(404).json({ error: 'Ficha não encontrada' });
      await redis('SET', `sheet:${id}`, raw);
      return res.json({ ok: true });
    }

    res.status(405).end();
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
