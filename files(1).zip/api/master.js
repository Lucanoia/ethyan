const { redis } = require('./_db');

module.exports = async (req, res) => {
  try {
    const key = process.env.MASTER_KEY;
    if (!key || req.headers['x-master-key'] !== key)
      return res.status(401).json({ error: 'Senha do mestre incorreta' });

    const ids = (await redis('SMEMBERS', 'sheets')) || [];
    if (!ids.length) return res.json([]);
    const raws = await redis('MGET', ...ids.map((i) => `sheet:${i}`));
    const list = raws
      .map((r, n) => (r ? { id: ids[n], ...JSON.parse(r) } : null))
      .filter(Boolean)
      .sort((a, b) => (b.updated || 0) - (a.updated || 0));
    res.json(list);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
